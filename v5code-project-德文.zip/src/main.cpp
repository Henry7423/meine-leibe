/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Modul:         main.cpp                                                 */
/*    Autor:         VEX                                                      */
/*    Erstellt:      Do 26. Sep 2019                                          */
/*    Beschreibung:  Wettbewerbsvorlage                                       */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE KONFIGURIERTE GERÄTE ----
// Roboterkonfiguration:
// [Name]               [Typ]         [Port(s)]
// Left1                Motor         1               
// Left2                Motor         2               
// Left3                Motor         3               
// Right1               Motor         4               
// Right2               Motor         5               
// Right3               Motor         6               
// ---- ENDE VEXCODE KONFIGURIERTE GERÄTE ----

#include "vex.h"
using namespace vex;

// Eine globale Instanz von Wettbewerb
competition Competition;

// Definieren Sie hier Ihre globalen Instanzen von Motoren und anderen Geräten

/*---------------------------------------------------------------------------*/
/*                          Vorautonome Funktionen                           */
/*                                                                           */
/*  Hier können Sie einige Aktionen durchführen, bevor der Wettbewerb        */
/*  beginnt. Diese Aktionen sollten Sie in der folgenden Funktion ausführen. */
/*  Sie müssen aus dieser Funktion zurückkehren, sonst werden die autonomen  */
/*  und benutzergesteuerten Aufgaben nicht gestartet. Diese Funktion wird    */
/*  nur einmal aufgerufen, nachdem der V5 eingeschaltet wurde und nicht      */
/*  jedes Mal, wenn der Roboter deaktiviert wird.                            */
/*---------------------------------------------------------------------------*/
motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB, leftMotorC);
motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB, rightMotorC);
motor_group intakeGroup = motor_group(intake1, intake2);
inertial DrivetrainInertial = inertial(PORT7);
smartdrive Drivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, DrivetrainInertial, 299.24, 320, 40, mm, 2);

void pre_auton(void) {
  // Initialisierung der Roboterkonfiguration. NICHT ENTFERNEN!
  vexcodeInit();
  
  
  // Alle Aktivitäten, die vor dem Start des Wettbewerbs stattfinden
  // Beispiel: Löschen von Encodern, Einstellen von Servopositionen, ...
}


//Einstellungen
double kP = 0.0;
double kI = 0.0; // Gakirah Barnes Referenz!
double kD = 0.0;
double turnkP = 0.0;
double turnkI = 0.0;
double turnkD = 0.0;

//Autonome Einstellungen
int desiredValue = 200;
int desiredTurnValue = 0;

int error; //Sensorwert - Sollwert = Positionswert
int prevError = 0; //Position vor 20 Millisekunden
int derivative; // Fehler - prevError = Geschwindigkeit
int totalError = 0; //totalError = totalError + Fehler

int turnError; //Sensorwert - Sollwert = Positionswert
int turnPrevError = 0; //Position vor 20 Millisekunden
int turnDerivative; // Fehler - prevError = Geschwindigkeit
int turnTotalError = 0; //totalError = totalError + Fehler

bool resetDriveSensors = false; 


bool enableDrivePID = true;



int drivePID(){
  while(enableDrivePID){
    
    if (resetDriveSensors){
      resetDriveSensors = false;

      LeftDriveSmart.setPosition(0, degrees);
      RightDriveSmart.setPosition(0, degrees);
    }


    //Positionen abrufen
    int leftDrivePosition = LeftDriveSmart.position(degrees);
    int rightDrivePosition = RightDriveSmart.position(degrees);
    /*
        LATERALE BEWEGUNG PIDs (sie pid auf meine Bewegung bis ich lateral)
    */
    //Durchschnitt berechnen
    int averagePosition = (leftDrivePosition+rightDrivePosition)/2; 


    //Proportional
    error = averagePosition - desiredValue;

    //Differentiell
    derivative = error - prevError;

    //Integral
    totalError += error;
   

    double lateralMotorPower = error * kP + derivative * kD + totalError * kI;

    /*
          DREH PIDs (in etwas anderes ;D)
    */
    //Durchschnitt berechnen
    int turnDifference = leftDrivePosition - rightDrivePosition; 


    //Proportional
    turnError = turnDifference - desiredTurnValue;

    //Differentiell
    turnDerivative = turnError - turnPrevError;

    //Integral
    turnTotalError += turnError;
   

    double turnMotorPower = turnError * turnkP + turnDerivative * turnkD + turnTotalError * turnkI;

    ////

    LeftDriveSmart.spin(forward, lateralMotorPower + turnMotorPower, voltageUnits::volt);
    RightDriveSmart.spin(forward, lateralMotorPower - turnMotorPower, voltageUnits::volt);


    //Code
    prevError = error;
    turnPrevError = turnError;
    vex::task::sleep(20);
  }

  return 1;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonome Aufgabe                             */
/*                                                                           */
/*  Diese Aufgabe wird verwendet, um den Roboter während der autonomen       */
/*  Phase eines VEX-Wettbewerbs zu steuern.                                  */
/*                                                                           */
/*  Sie müssen den Code anpassen, um eigene roboter-spezifische Befehle      */
/*  hinzuzufügen.                                                            */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Hier Benutzer-Code für autonome Phase einfügen.
  // ..........................................................................

  vex::task asdf(drivePID);
  
  resetDriveSensors = true;
  desiredValue = 300;
  desiredTurnValue = 600;

  
  vex::task::sleep(1000);
  
  resetDriveSensors = true;
  desiredValue = 300;
  desiredTurnValue = 300;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                            Benutzersteuerungsaufgabe                      */
/*                                                                           */
/*  Diese Aufgabe wird verwendet, um den Roboter während der                 */
/*  benutzergesteuerten Phase eines VEX-Wettbewerbs zu steuern.              */
/*                                                                           */
/*  Sie müssen den Code anpassen, um hier eigene roboter-spezifische         */
/*  Befehle hinzuzufügen.                                                    */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // Benutzersteuerungscode hier, innerhalb der Schleife
 
  double turnImportance = 0.5;
 
  while (1) {
    // Dies ist die Hauptausführungsschleife für das benutzergesteuerte Programm.
    // Jedes Mal, wenn die Schleife durchlaufen wird, sollte Ihr Programm die
    // Motor- und Servowerte basierend auf den Joystick-Eingaben aktualisieren.

    // ........................................................................
    // Benutzer-Code hier einfügen. Hier verwenden Sie die Joystick-Werte, um
    // die Motoren usw. zu aktualisieren.
    // ........................................................................
   
    //Bewegung
    double turnVal = Controller1.Axis2.position(percent);
    double forwardVal = Controller1.Axis3.position(percent);

    double turnVolts = turnVal*0.12;
    if (turnVolts < 0 ){
      turnVolts = -1 * turnVolts;
    }
    double forwardVolts = forwardVal * 0.12 * (1-(turnVolts/12.0)* turnImportance);

    LeftDriveSmart.spin(forward, forwardVolts + turnVolts, voltageUnits::volt);
    RightDriveSmart.spin(forward, forwardVolts - turnVolts, voltageUnits::volt);

    intakeGroup.spin(forward, Controller1.Axis4.value(), pct);
    //Drehen
    while(Controller1.Axis1.value() > 0){
      Drivetrain.turn(right, 450, rpm);
    }
    while(Controller1.Axis1.value() < 0){
      Drivetrain.turn(left, 450, rpm);
    }

    
    wait(20, msec); // Warten Sie die Aufgabe eine kurze Zeit lang, um
                    // Ressourcenverschwendung zu vermeiden.
  }
}

//
// Main wird die Wettbewerbsfunktionen und Rückruffunktionen einrichten.
//
int main() {
  // Rückruffunktionen für die autonomen und benutzergesteuerten Perioden einrichten.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Führen Sie die vorautonome Funktion aus.
  pre_auton();

  // Verhindert das Beenden von main mit einer Endlosschleife.
  while (true) {
    wait(100, msec);
  }
}
